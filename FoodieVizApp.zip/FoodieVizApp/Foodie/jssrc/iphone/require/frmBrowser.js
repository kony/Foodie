define("frmBrowser", function() {
    return function(controller) {
        function addWidgetsfrmBrowser() {
            this.setDefaultUnit(kony.flex.DP);
            var browser = new kony.ui.Browser({
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "htmlString": "Browser",
                "id": "browser",
                "isVisible": true,
                "left": "0dp",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            this.add(browser);
        };
        return [{
            "addWidgets": addWidgetsfrmBrowser,
            "enabledForIdleTimeout": false,
            "id": "frmBrowser",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "info": {
                "kuid": "4db154e0fdc249db93548d33e17fcc52"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});