define("frmResDetails", function() {
    return function(controller) {
        function addWidgetsfrmResDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnFavourite = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFavourite",
                "height": "30dp",
                "id": "btnFavourite",
                "isVisible": true,
                "onClick": controller.AS_Button_35757ba08e0042db8e42402dc4f81253,
                "right": "10dp",
                "skin": "sknBtnFavourite",
                "top": "11dp",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Details",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_ca05cd8f5cf545cfab4f3bc54b9ba5c4,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(btnFavourite, lblztitle, btnHome);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxTitle",
                "top": "9%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var imgResIcon = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgResIcon",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRating = new kony.ui.Label({
                "height": "4%",
                "id": "lblRating",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblRating",
                "text": "4.5",
                "top": "16dp",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblName = new kony.ui.Label({
                "id": "lblName",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblResNameWhite",
                "text": "Restaurant name",
                "top": "125dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxInfoRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "70%",
                "id": "flxInfoRoot",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "skin": "sknFlxDarkGrey2",
                "top": "30%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxInfoRoot.setDefaultUnit(kony.flex.DP);
            flxInfoRoot.add();
            var flxScrollInfoRoot = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "70%",
                "horizontalScrollIndicator": true,
                "id": "flxScrollInfoRoot",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxScrollBoxGrey",
                "top": "30%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxScrollInfoRoot.setDefaultUnit(kony.flex.DP);
            var flxCusinies = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusinies",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxCusinies.setDefaultUnit(kony.flex.DP);
            var Label09e3a6d8dac074c = new kony.ui.Label({
                "height": "30dp",
                "id": "Label09e3a6d8dac074c",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Cuisines",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblCusines = new kony.ui.Label({
                "id": "lblCusines",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxCusinies.add(Label09e3a6d8dac074c, lblCusines);
            var CopylblLine014ea075be44e41 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine014ea075be44e41",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxRating = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxRating",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRating.setDefaultUnit(kony.flex.DP);
            var lblRatingTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblRatingTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Rating",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblUserRating = new kony.ui.Label({
                "id": "lblUserRating",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var Label04772d85fe30e4b = new kony.ui.Label({
                "id": "Label04772d85fe30e4b",
                "isVisible": false,
                "left": "22dp",
                "skin": "slLabel",
                "text": "votes",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblVotes = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblVotes",
                "isVisible": false,
                "left": "4dp",
                "skin": "slLabel",
                "text": "50",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxRating.add(lblRatingTitle, lblUserRating, Label04772d85fe30e4b, lblVotes);
            var CopylblLine0aced769789dd40 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine0aced769789dd40",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxCost = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxCost",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxCost.setDefaultUnit(kony.flex.DP);
            var lblCostTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCostTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Cost",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblCost = new kony.ui.Label({
                "height": "30dp",
                "id": "lblCost",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxCost.add(lblCostTitle, lblCost);
            var CopylblLine04821f55962dc44 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine04821f55962dc44",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblLine",
                "width": "97%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var lblAddressTitle = new kony.ui.Label({
                "height": "30dp",
                "id": "lblAddressTitle",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblResInfo",
                "text": "Address",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var lblAddress = new kony.ui.Label({
                "id": "lblAddress",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblCuisines",
                "text": "Address",
                "top": "30dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxAddress.add(lblAddressTitle, lblAddress);
            var lblLine = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "lblLine",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLine",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "onClick": controller.AS_FlexContainer_c00e106eda614b09b4aebff533c06a9f,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMenu.setDefaultUnit(kony.flex.DP);
            var btnResIcon = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnResrMenu",
                "height": "40dp",
                "id": "btnResIcon",
                "isVisible": true,
                "left": "5dp",
                "onClick": controller.AS_Button_gccb6d5ce90549eeb3831b46f0668c77,
                "skin": "sknBtnResrMenu",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var Label0he6e6f4a21f045 = new kony.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "Label0he6e6f4a21f045",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopyslLabel0edf8dd92c08948",
                "text": "Click for menu",
                "top": "8dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxMenu.add(btnResIcon, Label0he6e6f4a21f045);
            var CopylblLine0d7158a0c2ab344 = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine0d7158a0c2ab344",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLine",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxFavourite = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxFavourite",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "onClick": controller.AS_FlexContainer_je6d2c828f1c4d3da5d633f2ea959615,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxFavourite.setDefaultUnit(kony.flex.DP);
            var imgFavourite = new kony.ui.Image2({
                "centerY": "50%",
                "height": "40dp",
                "id": "imgFavourite",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "stars.png",
                "width": "40dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Label0ebb87c0388c440 = new kony.ui.Label({
                "centerY": "50%",
                "id": "Label0ebb87c0388c440",
                "isVisible": true,
                "left": "0dp",
                "skin": "CopyslLabel0e49e2f6e0b7a47",
                "text": "Add To Favourite",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            flxFavourite.add(imgFavourite, Label0ebb87c0388c440);
            var CopylblLine0ba1beb7c51c64a = new kony.ui.Label({
                "bottom": "0%",
                "height": "1dp",
                "id": "CopylblLine0ba1beb7c51c64a",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLine",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var flxExtra = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxExtra",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxWhite",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxExtra.setDefaultUnit(kony.flex.DP);
            var btnMap = new kony.ui.Button({
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknBtnMap",
                "height": "45dp",
                "id": "btnMap",
                "isVisible": true,
                "onClick": controller.AS_Button_g076c3717f304f15a92b480da27a7495,
                "right": "10dp",
                "skin": "sknBtnGreen",
                "text": "Locate on Map",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxExtra.add(btnMap);
            flxScrollInfoRoot.add(flxCusinies, CopylblLine014ea075be44e41, flxRating, CopylblLine0aced769789dd40, flxCost, CopylblLine04821f55962dc44, flxAddress, lblLine, flxMenu, CopylblLine0d7158a0c2ab344, flxFavourite, CopylblLine0ba1beb7c51c64a, flxExtra);
            flxRootContainer.add(imgResIcon, lblRating, lblName, flxInfoRoot, flxScrollInfoRoot);
            this.add(flxTitle, flxRootContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmResDetails,
            "enabledForIdleTimeout": false,
            "id": "frmResDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "title": "Details",
            "info": {
                "kuid": "3e8d7aa94f854182a0bf598ffd5826f5"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "sknLblFrmTitle"
        }]
    }
});