define("flxSectionHeaderRoot", function() {
    return function(controller) {
        var flxSectionHeaderRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "50dp",
            "id": "flxSectionHeaderRoot",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "skin": "slFbox"
        }, {}, {});
        flxSectionHeaderRoot.setDefaultUnit(kony.flex.DP);
        var Label0h078767fae4245 = new kony.ui.Label({
            "centerX": "50%",
            "centerY": "50%",
            "id": "Label0h078767fae4245",
            "isVisible": true,
            "skin": "slLabel",
            "text": "Label",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        flxSectionHeaderRoot.add(Label0h078767fae4245);
        return flxSectionHeaderRoot;
    }
})