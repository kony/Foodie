define("frmFavourite", function() {
    return function(controller) {
        function addWidgetsfrmFavourite() {
            this.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_f1f1410203244258a33f3c2e49cd4d11,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Favourite",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            flxTitle.add(btnHome, lblztitle);
            var flxRootContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "91%",
                "id": "flxRootContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxDarkGrey2",
                "top": "9%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRootContainer.setDefaultUnit(kony.flex.DP);
            var segRestaurant = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }, {
                    "imgDelete": "deletee.png",
                    "imgResIcon": "imagedrag.png",
                    "lblCuisines": "Cuisines",
                    "lblLine": "",
                    "lblRating": "4.5",
                    "lblResName": "Restaurant name"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRestaurant",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_a6ad63bb0a4844e0982c8d98b1fcc8d6,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "Copyseg0ad33c17cd47345",
                "rowSkin": "Copyseg0ad33c17cd47345",
                "rowTemplate": "flxFavRootContainer",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": true,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDelete": "flxDelete",
                    "flxDeleteRestaurant": "flxDeleteRestaurant",
                    "flxFavRootContainer": "flxFavRootContainer",
                    "flxRestaurantInfo": "flxRestaurantInfo",
                    "flxTitle": "flxTitle",
                    "imgDelete": "imgDelete",
                    "imgResIcon": "imgResIcon",
                    "lblCuisines": "lblCuisines",
                    "lblLine": "lblLine",
                    "lblRating": "lblRating",
                    "lblResName": "lblResName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRootContainer.add(segRestaurant);
            this.add(flxTitle, flxRootContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmFavourite,
            "enabledForIdleTimeout": false,
            "id": "frmFavourite",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "info": {
                "kuid": "3b98cb91816447a899c7cd3b761440d2"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": true,
            "titleBarSkin": "slTitleBar",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});