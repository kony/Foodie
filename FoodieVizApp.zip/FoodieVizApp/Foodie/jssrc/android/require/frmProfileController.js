define({
    "onNavigate": function() {
        this.view.imgProfile.src = kony.store.getItem("IMAGE_URL");
        this.view.lblFNameTxt.text = kony.store.getItem("FNAME");
        this.view.lblLnameTxt.text = kony.store.getItem("LNAME");
        this.view.lblEmailTxt.text = kony.store.getItem("EMAIL");
        this.view.lblMobTxt.text = kony.store.getItem("MOB");
        var custmetrics = [{
            "profile": "form profile"
        }];
        KNYMetricsService.sendCustomMetrics("frmProfile", custmetrics);
        KNYMetricsService.flushEvents();
    },
    "navigateToFormHome": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmHome");
            navigateObject.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "navigateToFormEditProfile": function() {
        try {
            var navigateObject = new kony.mvc.Navigation("frmEditProfile");
            navigateObject.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_1e3ede0adef04a10ad544461c4d00d3b": function AS_Button_1e3ede0adef04a10ad544461c4d00d3b(eventobject) {
        var self = this;
        this.navigateToFormEditProfile();
    },
    "AS_Button_6931871508be4397860d409f4d9cf8b3": function AS_Button_6931871508be4397860d409f4d9cf8b3(eventobject) {
        var self = this;
        this.navigateToFormHome();
    }
})