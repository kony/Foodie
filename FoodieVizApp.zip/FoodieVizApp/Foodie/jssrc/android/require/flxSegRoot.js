define("flxSegRoot", function() {
    return function(controller) {
        var flxSegRoot = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxSegRoot",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "skin": "sknFlxLightGrey"
        }, {}, {});
        flxSegRoot.setDefaultUnit(kony.flex.DP);
        var lblTitle = new kony.ui.Label({
            "height": "30dp",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblTitle",
            "text": "Title",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lblLine = new kony.ui.Label({
            "centerX": "50%",
            "height": "2dp",
            "id": "lblLine",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLine",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lblCity = new kony.ui.Label({
            "height": "30dp",
            "id": "lblCity",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblCuisines",
            "text": "City",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        flxSegRoot.add(lblTitle, lblLine, lblCity);
        return flxSegRoot;
    }
})