define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_c89261059d6743428e34064233f944c2: function AS_FlexContainer_c89261059d6743428e34064233f944c2(eventobject, context) {
        var self = this;
        this.removeRestaurant(eventobject, context);
    }
});