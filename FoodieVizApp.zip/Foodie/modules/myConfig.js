var RESTAURANT_CONFIG = {
  "USER_KEY": "de7c3b6703285fcd9c6d2e6c61eca6ee",
  "GOOGLE_PROVIDER":"ZGoogleOAuthv2",
  "FACEBOOK_PROVIDER":"ZFacebookOAuthv2",
  
  "RESTAURANT_INTEGRATION_SERVICE":"Restauants",
  "GET_RESTAURANT_OPERATION":"getRestaurants",
  "GET_CUISINES_OPERATION":"getCuisines",
  "GET_CITY_OPERATION":"getCity",
  
  "FACEBOOK_INTEGRATION_SERVICE":"ZFBGraphAPI",
  "FACEBOOK_OPERATION_NAME":"getUserDetails"
};
var KMSPROP={
  senderID:"947073648918"
};
var PROVIDER={
  "googleProvider":"ZGoogleOAuthv2",
  "facebookProvider":"FacebookLogin"
};
