define({
    "resObj": {},
    "oder_url": "",
    "navigateTofrmHome": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "onNavigate": function(restaurantObj) {
        if (restaurantObj === null || restaurantObj === undefined) return;
        this.resObj = restaurantObj;
        var menu_url = restaurantObj["menu_url"];
        this.view.browser.requestURLConfig = {
            "URL": menu_url
        };
        if (restaurantObj["oder_url"] !== null && restaurantObj["oder_url"] !== undefined) {
            oder_url = (restaurantObj["oder_url"]).trim();
            if (oder_url !== "") {
                this.view.btnOrder.setVisibility(true);
            }
        }
    },
    "order": function() {
        try {
            var navigateObj = new kony.mvc.Navigation("frmOrder");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_aee22295487245bb9a7073181fbea235": function AS_Button_aee22295487245bb9a7073181fbea235(eventobject) {
        var self = this;
        this.order();
    }
})