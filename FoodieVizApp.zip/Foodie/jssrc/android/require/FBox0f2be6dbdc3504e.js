define("FBox0f2be6dbdc3504e", function() {
    return function(controller) {
        FBox0f2be6dbdc3504e = new kony.ui.FlexContainer({
            "clipBounds": false,
            "height": "40dp",
            "id": "FBox0f2be6dbdc3504e",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "width": "100%"
        }, {}, {});
        FBox0f2be6dbdc3504e.setDefaultUnit(kony.flex.DP);
        var Label0i635dd339e0e47 = new kony.ui.Label({
            "id": "Label0i635dd339e0e47",
            "isVisible": true,
            "left": "29dp",
            "skin": "slLabel",
            "text": "Label",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "7dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "containerWeight": 100,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "hExpand": true,
            "margin": [1, 1, 1, 1],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {
            "textCopyable": false
        });
        FBox0f2be6dbdc3504e.add(Label0i635dd339e0e47);
        return FBox0f2be6dbdc3504e;
    }
})