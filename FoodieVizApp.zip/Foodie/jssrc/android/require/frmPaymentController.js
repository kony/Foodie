define({
    "onNavigate": function() {
        var custmetrics = [{
            "payment": "form payment"
        }];
        KNYMetricsService.sendCustomMetrics("frmPayment", custmetrics);
        KNYMetricsService.flushEvents();
    },
    "navigateTofrmHome": function() {
        var controllerScope = this;
        try {
            alert("order placed successfully.");
            var custmetrics = [{
                "order placed": "placed"
            }];
            KNYMetricsService.sendCustomMetrics("frmPayment", custmetrics);
            KNYMetricsService.flushEvents();
            var navigateObj = new kony.mvc.Navigation("frmHome");
            navigateObj.navigate();
        } catch (exp) {
            kony.print(JSON.stringify(exp));
        }
    },
    "AS_Button_ga709817d4fd4e349048942f3d6e8370": function AS_Button_ga709817d4fd4e349048942f3d6e8370(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    "AS_Button_e70257dae256419dbde3141af6263315": function AS_Button_e70257dae256419dbde3141af6263315(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    }
})