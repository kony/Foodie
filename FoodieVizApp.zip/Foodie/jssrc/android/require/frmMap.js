define("frmMap", function() {
    return function(controller) {
        function addWidgetsfrmMap() {
            this.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnFavourite = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnFavourite",
                "height": "30dp",
                "id": "btnFavourite",
                "isVisible": true,
                "onClick": controller.AS_Button_e9bb141705214ebfae8d61380c33c2b1,
                "right": "10dp",
                "skin": "sknBtnFavourite",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Details",
                "textStyle": {
                    "letterSpacing": 0,
                    "strikeThrough": false
                },
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_1f93c31c271f4b1f8abb09ea642814aa,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(btnFavourite, lblztitle, btnHome);
            var mapLocation = new kony.ui.Map({
                "calloutTemplate": "flxMapTmpRootContiner",
                "calloutWidth": 80,
                "defaultPinImage": "pinb.png",
                "height": "91%",
                "id": "mapLocation",
                "isVisible": true,
                "left": "0dp",
                "provider": constants.MAP_PROVIDER_GOOGLE,
                "top": "9%",
                "widgetDataMapForCallout": {
                    "btnMapTemplate": "btnMapTemplate",
                    "flxMapTmpRootContiner": "flxMapTmpRootContiner",
                    "flxNameContainer": "flxNameContainer",
                    "imgIcon": "imgIcon",
                    "lblCusines": "lblCusines",
                    "lblLine": "lblLine",
                    "lblLine2": "lblLine2",
                    "lblName": "lblName",
                    "lblRating": "lblRating"
                },
                "width": "100%",
                "zIndex": 1
            }, {}, {
                "mode": constants.MAP_VIEW_MODE_NORMAL,
                "showZoomControl": true,
                "zoomLevel": 15
            });
            this.add(flxTitle, mapLocation);
        };
        return [{
            "addWidgets": addWidgetsfrmMap,
            "enabledForIdleTimeout": false,
            "id": "frmMap",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmGrey",
            "title": "Location"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "footerOverlap": false,
            "headerOverlap": false,
            "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "sknLblFrmTitle",
            "windowSoftInputMode": constants.FORM_ADJUST_PAN
        }]
    }
});