define("flxMapTmpRootContiner", function() {
    return function(controller) {
        var flxMapTmpRootContiner = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxMapTmpRootContiner",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "onClick": controller.AS_FlexContainer_2661e555919d430cb950404c7f89eca6,
            "skin": "CopyslFbox023616774fbc44b",
            "width": "80%"
        }, {}, {});
        flxMapTmpRootContiner.setDefaultUnit(kony.flex.DP);
        var flxNameContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxNameContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "slFbox",
            "top": "0dp",
            "width": "90%",
            "zIndex": 10
        }, {}, {});
        flxNameContainer.setDefaultUnit(kony.flex.DP);
        var lblName = new kony.ui.Label({
            "height": "30dp",
            "id": "lblName",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBlue",
            "text": "Name",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblRating = new kony.ui.Label({
            "id": "lblRating",
            "isVisible": true,
            "right": "15dp",
            "skin": "sknLblRating",
            "text": "5",
            "top": "5dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxNameContainer.add(lblName, lblRating);
        var lblLine = new kony.ui.Label({
            "centerX": "50%",
            "height": "2dp",
            "id": "lblLine",
            "isVisible": true,
            "left": "15dp",
            "skin": "sknLblLine",
            "top": "0dp",
            "width": "90%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblCusines = new kony.ui.Label({
            "id": "lblCusines",
            "isVisible": true,
            "left": "15dp",
            "skin": "sknLblCuisines",
            "text": "Cuisines",
            "top": "0dp",
            "width": "90%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblLine2 = new kony.ui.Label({
            "height": "1dp",
            "id": "lblLine2",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblLine",
            "top": "20dp",
            "width": "95%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxMapTmpRootContiner.add(flxNameContainer, lblLine, lblCusines, lblLine2);
        return flxMapTmpRootContiner;
    }
})