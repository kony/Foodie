define("frmPayment", function() {
    return function(controller) {
        function addWidgetsfrmPayment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxDarkGreyBg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxTitle",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Payment",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_ga709817d4fd4e349048942f3d6e8370,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(lblztitle, btnHome);
            var flxPaymentOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxPaymentOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxDarkGreyBg",
                "top": "70dp",
                "width": "95%",
                "zIndex": 2
            }, {}, {});
            flxPaymentOptions.setDefaultUnit(kony.flex.DP);
            var Image0c6b70e15bac145 = new kony.ui.Image2({
                "centerX": "50%",
                "id": "Image0c6b70e15bac145",
                "isVisible": true,
                "skin": "slImage",
                "src": "payment.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentOptions.add(Image0c6b70e15bac145);
            var btnPayment = new kony.ui.Button({
                "bottom": "0dp",
                "centerX": "50%",
                "focusSkin": "sknBtnGreen",
                "height": "50dp",
                "id": "btnPayment",
                "isVisible": true,
                "left": "47dp",
                "onClick": controller.AS_Button_e70257dae256419dbde3141af6263315,
                "skin": "sknBtnGreen",
                "text": "confirm",
                "width": "100%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxRoot.add(flxTitle, flxPaymentOptions, btnPayment);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmPayment,
            "enabledForIdleTimeout": false,
            "id": "frmPayment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "info": {
                "kuid": "ccc21b862e1548a481a79f8a331d9958"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});