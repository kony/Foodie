define("frmOrder", function() {
    return function(controller) {
        function addWidgetsfrmOrder() {
            this.setDefaultUnit(kony.flex.DP);
            var flxRoot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRoot",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "skin": "sknFlxDarkGrey",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxRoot.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "skin": "sknFlxTitle",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblztitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblztitle",
                "isVisible": true,
                "skin": "sknLblTitle2",
                "text": "Order",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "textCopyable": false,
                "wrapping": constants.WIDGET_TEXT_WORD_WRAP
            });
            var btnHome = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnHome",
                "height": "35dp",
                "id": "btnHome",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_bc66672300d246df813757cfb5a121c1,
                "skin": "sknBtnHome",
                "width": "35dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxTitle.add(lblztitle, btnHome);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "500dp",
                "id": "flxContent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "skin": "slFbox",
                "top": "80dp",
                "width": "95%",
                "zIndex": 2
            }, {}, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var tabPaneOrder = new kony.ui.TabPane({
                "activeSkin": "tabCanvas",
                "activeTabs": [0],
                "height": "385dp",
                "id": "tabPaneOrder",
                "inactiveSkin": "tabCanvasInactive",
                "isVisible": false,
                "layoutType": constants.CONTAINER_LAYOUT_BOX,
                "left": "0dp",
                "top": "0dp",
                "viewConfig": {
                    "collapsibleViewConfig": {
                        "imagePosition": constants.TABPANE_COLLAPSIBLE_IMAGE_POSITION_RIGHT,
                        "imageposition": "right",
                        "tabNameAlignment": constants.TABPANE_COLLAPSIBLE_TABNAME_ALIGNMENT_LEFT,
                        "tabnamealignment": "left",
                        "toggleTabs": false,
                        "toggletabs": false
                    },
                    "collapsibleviewconfig": {
                        "imagePosition": constants.TABPANE_COLLAPSIBLE_IMAGE_POSITION_RIGHT,
                        "imageposition": "right",
                        "tabNameAlignment": constants.TABPANE_COLLAPSIBLE_TABNAME_ALIGNMENT_LEFT,
                        "tabnamealignment": "left",
                        "toggleTabs": false,
                        "toggletabs": false
                    },
                    "pageViewConfig": {
                        "needPageIndicator": true
                    },
                    "tabViewConfig": {
                        "headerPosition": constants.TAB_HEADER_POSITION_TOP,
                        "image1": "tableftarrow.png",
                        "image2": "tabrightarrow.png"
                    },
                },
                "viewType": constants.TABPANE_VIEW_TYPE_TABVIEW,
                "width": "100%",
                "zIndex": 1
            }, {
                "layoutType": constants.CONTAINER_LAYOUT_BOX,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            var tabStarter = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "tabStarter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "orientation": constants.BOX_LAYOUT_VERTICAL,
                "skin": "slTab",
                "tabName": "Starter",
                "width": "100%"
            }, {
                "layoutType": kony.flex.FREE_FORM,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            tabStarter.setDefaultUnit(kony.flex.DP);
            var segStarter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "120dp",
                "id": "segStarter",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            tabStarter.add(segStarter);
            tabPaneOrder.addTab("tabStarter", "Starter", null, tabStarter, null);
            var tabMainCourse = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "tabMainCourse",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "orientation": constants.BOX_LAYOUT_VERTICAL,
                "skin": "slTab",
                "tabName": "MainCourse",
                "width": "100%"
            }, {
                "layoutType": kony.flex.FREE_FORM,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            tabMainCourse.setDefaultUnit(kony.flex.DP);
            var CopysegStarter0j3e51a9c649b48 = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "120dp",
                "id": "CopysegStarter0j3e51a9c649b48",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            tabMainCourse.add(CopysegStarter0j3e51a9c649b48);
            tabPaneOrder.addTab("tabMainCourse", "MainCourse", null, tabMainCourse, null);
            var tabDesert = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "tabDesert",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "orientation": constants.BOX_LAYOUT_VERTICAL,
                "skin": "slTab",
                "tabName": "Desert",
                "width": "100%"
            }, {
                "layoutType": kony.flex.FREE_FORM,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            tabDesert.setDefaultUnit(kony.flex.DP);
            var CopysegStarter0a256c285657249 = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "120dp",
                "id": "CopysegStarter0a256c285657249",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            tabDesert.add(CopysegStarter0a256c285657249);
            tabPaneOrder.addTab("tabDesert", "Desert", null, tabDesert, null);
            var Segment0i8c454565bb745 = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "data": [
                    [{
                            "Label0h078767fae4245": "Label"
                        },
                        [{
                            "Label0i635dd339e0e47": "Label"
                        }, {
                            "Label0i635dd339e0e47": "Label"
                        }, {
                            "Label0i635dd339e0e47": "Label"
                        }]
                    ],
                    [{
                            "Label0h078767fae4245": "Label"
                        },
                        [{
                            "Label0i635dd339e0e47": "Label"
                        }, {
                            "Label0i635dd339e0e47": "Label"
                        }, {
                            "Label0i635dd339e0e47": "Label"
                        }, {
                            "Label0i635dd339e0e47": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "height": "500dp",
                "id": "Segment0i8c454565bb745",
                "isVisible": true,
                "left": "7dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "FBox0f2be6dbdc3504e",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": "flxSectionHeaderRoot",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "Label0h078767fae4245": "Label0h078767fae4245",
                    "Label0i635dd339e0e47": "Label0i635dd339e0e47",
                    "flxSectionHeaderRoot": "flxSectionHeaderRoot"
                },
                "width": "100%",
                "zIndex": 2
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "bounces": true,
                "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
                "enableDictionary": false,
                "indicator": constants.SEGUI_ROW_SELECT,
                "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
                "showProgressIndicator": true
            });
            flxContent.add(tabPaneOrder, Segment0i8c454565bb745);
            var btnOrder = new kony.ui.Button({
                "bottom": "0dp",
                "focusSkin": "sknBtnGreen",
                "height": "10%",
                "id": "btnOrder",
                "isVisible": true,
                "onClick": controller.AS_Button_f61b6da550754cb3864e11c8a729c9c3,
                "skin": "sknBtnGreen",
                "text": "ORDER",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            var Button0bce9cdca7a3c46 = new kony.ui.Button({
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "Button0bce9cdca7a3c46",
                "isVisible": false,
                "left": "43dp",
                "onClick": controller.AS_Button_a918b74ac046444499e36fbd8a268a0a,
                "skin": "slButtonGlossBlue",
                "text": "Button",
                "top": "405dp",
                "width": "260dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "showProgressIndicator": true
            });
            flxRoot.add(flxTitle, flxContent, btnOrder, Button0bce9cdca7a3c46);
            this.add(flxRoot);
        };
        return [{
            "addWidgets": addWidgetsfrmOrder,
            "enabledForIdleTimeout": false,
            "id": "frmOrder",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "info": {
                "kuid": "fe6bafba26a445efabc3330fe3909cf1"
            }
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});