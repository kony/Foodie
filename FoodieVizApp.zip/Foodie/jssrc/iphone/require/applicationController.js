define({
    AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8: function AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8(eventobject) {
        var self = this;
        return setCallBacks.call(this);
    },
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("CopyFBox06e2541c111b848", "CopyFBox06e2541c111b848", "CopyFBox06e2541c111b848Controller");
        kony.mvc.registry.add("CopyFBox08c606abedf334f", "CopyFBox08c606abedf334f", "CopyFBox08c606abedf334fController");
        kony.mvc.registry.add("FBox0da8ea37aaf534e", "FBox0da8ea37aaf534e", "FBox0da8ea37aaf534eController");
        kony.mvc.registry.add("FBox0f2be6dbdc3504e", "FBox0f2be6dbdc3504e", "FBox0f2be6dbdc3504eController");
        kony.mvc.registry.add("flxSectionHeaderRoot", "flxSectionHeaderRoot", "flxSectionHeaderRootController");
        kony.mvc.registry.add("flxSegRoot", "flxSegRoot", "flxSegRootController");
        kony.mvc.registry.add("flxFavRootContainer", "flxFavRootContainer", "flxFavRootContainerController");
        kony.mvc.registry.add("flxRootContainer", "flxRootContainer", "flxRootContainerController");
        kony.mvc.registry.add("flxMapTmpRootContiner", "flxMapTmpRootContiner", "FlexContainer0a038f14ef33446Controller");
        kony.mvc.registry.add("frmBrowser", "frmBrowser", "frmBrowserController");
        kony.mvc.registry.add("frmEditProfile", "frmEditProfile", "frmEditProfileController");
        kony.mvc.registry.add("frmFavourite", "frmFavourite", "frmFavouriteController");
        kony.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        kony.mvc.registry.add("frmLogin", "frmLogin", "frmLoginController");
        kony.mvc.registry.add("frmMap", "frmMap", "frmMapController");
        kony.mvc.registry.add("frmOrder", "frmOrder", "frmOrderController");
        kony.mvc.registry.add("frmPayment", "frmPayment", "frmPaymentController");
        kony.mvc.registry.add("frmProfile", "frmProfile", "frmProfileController");
        kony.mvc.registry.add("frmResDetails", "frmResDetails", "frmResDetailsController");
        kony.mvc.registry.add("frmRestaurantMenu", "frmRestaurantMenu", "frmRestaurantMenuController");
        kony.mvc.registry.add("frmSearchRestaurant", "frmSearchRestaurant", "frmSearchRestaurantController");
        kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
        kony.application.setDefaultTextboxPadding(false);
        kony.application.setRespectImageSizeForImageWidgetAlignment(true);
        setAppBehaviors();
        if (typeof startBackgroundWorker != "undefined") {
            startBackgroundWorker();
        }
    },
    postAppInitCallBack: function() {
        return AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8();
    },
    appmenuseq: function() {
        new kony.mvc.Navigation("frmLogin").navigate();
    }
});