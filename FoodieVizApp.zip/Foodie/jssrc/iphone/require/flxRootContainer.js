define("flxRootContainer", function() {
    return function(controller) {
        var flxRootContainer = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "70dp",
            "id": "flxRootContainer",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "skin": "CopyslFbox01adde275a1d34d"
        }, {}, {});
        flxRootContainer.setDefaultUnit(kony.flex.DP);
        var flxRestaurantInfo = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "68dp",
            "id": "flxRestaurantInfo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "sknFlxWhite",
            "top": "0dp",
            "width": "95%",
            "zIndex": 1
        }, {}, {});
        flxRestaurantInfo.setDefaultUnit(kony.flex.DP);
        var imgResIcon = new kony.ui.Image2({
            "centerY": "50%",
            "height": "80%",
            "id": "imgResIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "imagedrag.png",
            "width": "18%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var flxTitle = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "28dp",
            "id": "flxTitle",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "19%",
            "skin": "slFbox",
            "top": "0dp",
            "width": "81%",
            "zIndex": 1
        }, {}, {});
        flxTitle.setDefaultUnit(kony.flex.DP);
        var lblResName = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblResName",
            "isVisible": true,
            "left": "0dp",
            "skin": "CopyslLabel0649382ce57cb45",
            "text": "Restaurant name",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        var lblRating = new kony.ui.Label({
            "centerY": "50%",
            "height": "90%",
            "id": "lblRating",
            "isVisible": true,
            "right": "10dp",
            "skin": "sknLblRating",
            "text": "4.5",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [1, 0, 1, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxTitle.add(lblResName, lblRating);
        var lblCuisines = new kony.ui.Label({
            "height": "30dp",
            "id": "lblCuisines",
            "isVisible": true,
            "left": "19%",
            "skin": "sknLblSubTitle",
            "text": "Cuisines",
            "top": "28dp",
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxRestaurantInfo.add(imgResIcon, flxTitle, lblCuisines);
        var lblLine = new kony.ui.Label({
            "centerX": "50%",
            "height": "2dp",
            "id": "lblLine",
            "isVisible": true,
            "skin": "sknLblLine",
            "top": "0dp",
            "width": "94%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false,
            "wrapping": constants.WIDGET_TEXT_WORD_WRAP
        });
        flxRootContainer.add(flxRestaurantInfo, lblLine);
        return flxRootContainer;
    }
})