//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "Foodie",
    appName: "Foodie",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.17.181",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "Foodie",
    isturlbase: "https://mfpm.qa-konycloud.com/services",
    isMFApp: true,
    appKey: "a70a0adb2f3797784edd3b0c859052a5",
    appSecret: "4703f24be1bca6e968be2b866d696223",
    serviceUrl: "https://100000347.auth.qa-konycloud.com/appconfig",
    svcDoc: {
        "appId": "e8367c95-3f8d-429f-b8e2-5c908353a186",
        "baseId": "a1d66eeb-e04a-4a0e-858c-5132d43ed0ae",
        "name": "Foodie",
        "selflink": "https://100000347.auth.qa-konycloud.com/appconfig",
        "login": [{
            "type": "oauth2",
            "prov": "ZGoogleOAuthv2",
            "url": "https://100000347.auth.qa-konycloud.com",
            "alias": "ZGoogleOAuthv2"
        }, {
            "type": "oauth2",
            "prov": "ZFacebookOAuthv2",
            "url": "https://100000347.auth.qa-konycloud.com",
            "alias": "ZFacebookOAuthv2"
        }],
        "messagingsvc": {
            "appId": "e8367c95-3f8d-429f-b8e2-5c908353a186",
            "url": "https://mfpm.messaging.qa-konycloud.com/api/v1"
        },
        "integsvc": {
            "Restauants": "https://mfpm.qa-konycloud.com/services/Restauants",
            "ZFBGraphAPI": "https://mfpm.qa-konycloud.com/services/ZFBGraphAPI"
        },
        "reportingsvc": {
            "custom": "https://mfpm.qa-konycloud.com/services/CMS",
            "session": "https://mfpm.qa-konycloud.com/services/IST"
        },
        "services_meta": {
            "Restauants": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/Restauants",
                "type": "integsvc"
            },
            "ZFBGraphAPI": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/ZFBGraphAPI",
                "type": "integsvc"
            },
            "Profile": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/data/v1/Profile",
                "metadata_url": "https://mfpm.qa-konycloud.com/services/metadata/v1/Profile",
                "type": "objectsvc"
            },
            "NearByRestaurant": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/data/v1/NearByRestaurant",
                "metadata_url": "https://mfpm.qa-konycloud.com/services/metadata/v1/NearByRestaurant",
                "type": "objectsvc"
            },
            "RestaurantDetails": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/data/v1/RestaurantDetails",
                "metadata_url": "https://mfpm.qa-konycloud.com/services/metadata/v1/RestaurantDetails",
                "type": "objectsvc"
            },
            "FavouriteRestaurant": {
                "version": "1.0",
                "url": "https://mfpm.qa-konycloud.com/services/data/v1/FavouriteRestaurant",
                "metadata_url": "https://mfpm.qa-konycloud.com/services/metadata/v1/FavouriteRestaurant",
                "type": "objectsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "https://mfpm.qa-konycloud.com/Foodie/MWServlet",
    secureurl: "https://mfpm.qa-konycloud.com/Foodie/MWServlet"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    kony.application.setCheckBoxSelectionImageAlignment(constants.CHECKBOX_SELECTION_IMAGE_ALIGNMENT_RIGHT);
    kony.application.setDefaultTextboxPadding(false);
    kony.application.setRespectImageSizeForImageWidgetAlignment(true);
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        isMVC: true,
        marginsIncludedInWidgetContainerWeight: true,
        APILevel: 7200
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    applicationController = require("applicationController");
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: applicationController.appInit,
        postappinit: applicationController.AS_AppEvents_j3fdee38f72542aaaf876abfc82dc2e8,
        showstartupform: function() {
            var startForm = new kony.mvc.Navigation("frmLogin");
            startForm.navigate();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "eventTypes": appConfig.eventTypes,
        "serviceUrl": appConfig.serviceUrl
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();
// If you wish to debug Application Initialization events, now is the time to
// place breakpoints.
debugger;