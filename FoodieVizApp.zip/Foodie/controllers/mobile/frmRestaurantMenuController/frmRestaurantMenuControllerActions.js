define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_aee22295487245bb9a7073181fbea235: function AS_Button_aee22295487245bb9a7073181fbea235(eventobject) {
        var self = this;
        this.order();
    }
});