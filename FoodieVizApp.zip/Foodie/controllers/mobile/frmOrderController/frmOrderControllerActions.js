define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_bc66672300d246df813757cfb5a121c1: function AS_Button_bc66672300d246df813757cfb5a121c1(eventobject) {
        var self = this;
        this.navigateTofrmHome();
    },
    AS_Button_f61b6da550754cb3864e11c8a729c9c3: function AS_Button_f61b6da550754cb3864e11c8a729c9c3(eventobject) {
        var self = this;
        this.makePayment();
    },
    AS_Button_a918b74ac046444499e36fbd8a268a0a: function AS_Button_a918b74ac046444499e36fbd8a268a0a(eventobject) {
        var self = this;
        this.makePayment();
    }
});