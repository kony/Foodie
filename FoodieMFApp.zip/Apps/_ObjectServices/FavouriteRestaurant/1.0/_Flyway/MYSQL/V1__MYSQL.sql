CREATE TABLE `Restaurant`(
	`aggregate_rating` VARCHAR(10),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`cuisines` VARCHAR(200),
	`device_id` VARCHAR(50) NOT NULL,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`name` VARCHAR(100),
	`resturant_id` VARCHAR(50) NOT NULL,
	`SoftDeleteFlag` BOOLEAN,
	`thumb` VARCHAR(300),
	PRIMARY KEY(`device_id`,`resturant_id`)
);
